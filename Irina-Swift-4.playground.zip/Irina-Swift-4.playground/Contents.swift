import UIKit

/*
 Assignment 4: Swift Protocols and Classes (Monster Edition):
    Objective:
        - Create a base protocol with common properties or methods for monsters.
        - Derive two child protocols for specific monster types.
        - Create four classes (two flying and two water monsters) conforming to these child protocols.
        - Write a function that accepts a collection of Monster objects and prints details about each.
 
    Instructions:
    Step 1: Define the Base Protocol
            Monster with:
                var name: String { get }
                func roar() -> String
 
    Step 2: Define Child Protocols
            FlyingMonster with:
                var wingSpan: Double { get }
                func fly() -> String
            WaterMonster with:
                var swimSpeed: Int { get }
                func swim() -> String
 
    Step 3: Create Four Classes
            * Dragon and Gryphon conforming to FlyingMonster.
            * Kraken and Merfolk conforming to WaterMonster.
 
    Step 4: Create a Function to Handle Monsters:
            * print MonsterDetails(monsters: [Monster]) to print information for each monster, using polymorphism to call appropriate methods based on their type.
 
 ******** Sample Output ********
 Fire Drake roars fiercely, shaking the ground!
 Fire Drake spreads its 15.0-meter wings and takes to the sky!
 -----------------------
 Sky Hunter screeches with a piercing cry!
 Sky Hunter soars high with its majestic 12.0-meter wings!
 -----------------------
 Sea Terror bellows from the deep, causing waves to crash!
 Sea Terror glides through the water at 20 knots!
 -----------------------
 Coral Queen sings an enchanting melody that stirs the seas!
 Coral Queen swims gracefully at 10 knots!
 -----------------------
 */


/*  Step 1: Define the Base Protocol
 Monster with:
     var name: String { get }
     func roar() -> String
*/
protocol Monster {
    var name: String { get }
    
    func roar() -> String
}

/* Step 2: Define Child Protocols
            FlyingMonster with:
                var wingSpan: Double { get }
                func fly() -> String
            WaterMonster with:
                var swimSpeed: Int { get }
                func swim() -> String
*/
protocol FlyingMonster: Monster {
    var wingSpan: Double { get }
    
    func fly() -> String
}

protocol WaterMonster: Monster {
    var swimSpeed: Int { get }
    
    func swim() -> String
}

/* Step 3: Create Four Classes:
           * Dragon and Gryphon conforming to FlyingMonster.
           * Kraken and Merfolk conforming to WaterMonster.
*/
class  Dragon: FlyingMonster {
    var name: String
    var wingSpan: Double
    
    init(wingSpan: Double, name: String) {
        self.wingSpan = wingSpan
        self.name = name
    }
    
    func roar() -> String {
        return "Fire \(self.name) roars fiercely, shaking the ground!"
    }
    func fly() -> String {
        return "Fire \(self.name) spreads its \(self.wingSpan)-meter wings and takes to the sky!"
    }
}

class Gryphon: FlyingMonster {
    var name: String
    var wingSpan: Double
    
    init(wingSpan: Double, name: String) {
        self.wingSpan = wingSpan
        self.name = name
    }
    
    func roar() -> String {
        return "Sky \(self.name) screeches with a piercing cry!"
    }
    func fly() -> String {
        return "Sky \(self.name) soars high with its majestic \(self.wingSpan)-meter wings!"
    }
}


class Kraken: WaterMonster {
    var name: String
    var swimSpeed: Int
    
    init(swimSpeed: Int, name: String) {
        self.swimSpeed = swimSpeed
        self.name = name
    }
    
    func roar() -> String {
        return "Sea \(self.name) bellows from the deep, causing waves to crash!"
    }
    func swim() -> String{
        return "Sea Terror glides through the water at \(self.swimSpeed) knots!"
    }
}

class  Merfolk: WaterMonster {
    var name: String
    var swimSpeed: Int
    
    init(swimSpeed: Int, name: String) {
        self.swimSpeed = swimSpeed
        self.name = name
    }
    
    func roar() -> String {
        return "Coral \(self.name) sings an enchanting melody that stirs the seas!"
    }
    func swim() -> String{
        return "Coral Queen swims gracefully at \(self.swimSpeed) knots!"
    }
}

/* Step 4: Create a Function to Handle Monsters:
            * print monsterDetails(monsters: [Monster]) to print information for each monster,
              using polymorphism to call appropriate methods based on their type.
*/
func monsterDetails(monsters: [Monster]){
    for m in monsters {
        if let d = m as? FlyingMonster {
            print("\(d.roar())")
            print("\(d.fly())")
        } else if let k = m as? WaterMonster {
            print("\(k.roar())")
            print("\(k.swim())")
        }
        print("-----------------------")
    }
}

var dra: Dragon = Dragon(wingSpan: 15.0, name: "Drake")
var hun: Gryphon = Gryphon(wingSpan: 12.0, name: "Hunter")
var ter: Kraken = Kraken(swimSpeed: 20, name: "Terror")
var que: Merfolk = Merfolk(swimSpeed: 10, name: "Queen")

var monster: [Monster] = [dra, hun, ter, que]

monsterDetails(monsters: monster)
    

/* ******** Sample Output ********
        Fire Drake roars fiercely, shaking the ground!  --- roar()
        Fire Drake spreads its 15.0-meter wings and takes to the sky! ---  fly()
        -----------------------
        Sky Hunter screeches with a piercing cry!
        Sky Hunter soars high with its majestic 12.0-meter wings!
        -----------------------
        Sea Terror bellows from the deep, causing waves to crash!
        Sea Terror glides through the water at 20 knots!
        -----------------------
        Coral Queen sings an enchanting melody that stirs the seas!
        Coral Queen swims gracefully at 10 knots!
        -----------------------
*/
